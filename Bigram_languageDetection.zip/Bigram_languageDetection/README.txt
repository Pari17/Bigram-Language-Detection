The program allows the user to detect languages (English, Spanish, French, German, Italian) using bigrams.

The program performs 3 actions:
1. Create models: Creates bigrams based on the language identification test files provided.
2. Manual entry: Allows you to enter any text to detect the language. Sample texts include "Hi how are you" or "Hola".
3. Load test files: Loads the all or one files in order to create probability and detect language within the file.